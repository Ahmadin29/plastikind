<?php
$this->load->view('layouts/header_user');
?>
<div class="container w3-padding-32 w3-row-padding">
	<div class="w3-row w3-col l3 rounded w3-margin-bottom">
		<div class="w3-col l12 shadow-sm w3-hide-small">
			<div class="w3-col l12 w3-padding-32 w3-light-grey w3-center">
				<?php

				if ($user->photo =="") {
					?>

					<img src="<?=base_url('/assets/images/user-default.png')?>" class="user-profile">

					<?php
				}else{
					?>

					<img src="<?=base_url('/assets/images/')?><?=$user->photo?>" class="user-profile">

					<?php
				}

				?>

				<h4 style="font-weight: bold;"><?=$user->f_name." ".$user->l_name?></h4>
				<i class="far fa-coins"></i> 300 Points
			</div>
			<div class="w3-padding w3-col l12">
				<a href="#" class="profile-nav"><i class="far fa-user-circle"></i> Edit Profile <i style="margin-top: 3px" class="far fa-chevron-right float-right"></i></a>
			</div>
		</div>
		<div class="w3-col l12 w3-margin-top shadow-sm rounded w3-hide-small">
			<div class="w3-padding w3-col l12 w3-green">
				<h6 style="font-weight: bold;color: white"><i class="far fa-truck" style="color: white"></i> Permintaan</h6>
			</div>
			<div class="w3-padding w3-col l12">
				<a href="#" class="profile-nav"><i class="far fa-clock"></i> Permintaan Ditunda <span class="w3-text-green float-right">90</span></a>
			</div>
			<div class="w3-padding w3-col l12">
				<a href="#" class="profile-nav"><i class="far fa-luggage-cart"></i> Permintaan Diproses <span class="w3-text-green float-right">90</span></a>
			</div>
			<div class="w3-padding w3-col l12">
				<a href="#" class="profile-nav"><i class="far fa-check-circle"></i> Permintaan Selesai <span class="w3-text-green float-right">90</span></a>
			</div>
		</div>
	</div>
	<div class="w3-col l9 w3-row-padding">
		<div class="w3-col l6 w3-padding-32 w3-border w3-margin-bottom w3-hover-shadow w3-center">
			<div class="w3-col l12 w3-center">
				<img src="<?=base_url('/assets/images/track.png')?>">
			</div>
			<div class="w3-col l12 w3-center">
				<h4 style="font-weight: bold;text-transform: uppercase;">Setor Sampah</h4>
			</div>
		</div>
		<div class="w3-col l6 w3-padding-32 w3-border w3-hover-shadow w3-center">
			<div class="w3-col l12 w3-center">
				<img src="<?=base_url('/assets/images/truck.png')?>">
			</div>
			<div class="w3-col l12 w3-center">
				<h4 style="font-weight: bold;text-transform: uppercase;">Minta Jemput Sampah</h4>
			</div>
		</div>
	</div>
</div>