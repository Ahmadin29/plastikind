<?php
$this->load->view('layouts/header');
?>


<section class="content">

	<div class="banner">
		<div class="container w3-row w3-padding-32">
			<div class="w3-col l6 m6 w3-padding-large" style="text-align: right">
				<img alt="banner" src="<?=base_url('/assets/images/banner.png')?>" style="width: 100%">
				<img alt="play-store" src="<?=base_url('/assets/images/ps.png')?>">
			</div>
			<div class="w3-col l6 m6">
				<div class="w3-card-4 w3-white w3-round w3-padding register">
					<header class="w3-container" style="border-bottom: 1px solid #eee;text-align: center;font-weight: bold;">
						<h3 class="banner-from-title w3-align-center">DAFTAR PLASTIKIND</h3>
					</header>
					<form id="form-daftar" method="post">
						<div class=" w3-margin-top w3-row">
							<div class="form-group w3-col l6 w3-padding-small">
								<label>Nama Depan</label>
								<input type="text" name="first_name" class="form-control" required>
							</div>
							<div class="form-group w3-col l6 w3-padding-small">
								<label>Nama Belakang</label>
								<input type="text" name="last_name" class="form-control" required>
							</div>

							<div class="form-group w3-col l6 w3-padding-small">
								<label>E-mail</label>
								<input type="email" name="email" class="form-control" required>
							</div>

							<div class="form-group w3-col l6 w3-padding-small">
								<label>No. Telpon</label>
								<input type="text" name="phone" class="form-control" required>
							</div>

							<div class="form-group w3-col l12 w3-padding-small">
								<label>Password</label>
								<input type="password" name="password" class="form-control" required>
							</div>
							<div class="form-group w3-col l12 w3-padding-small">
								<label>
									<small><i class="fas fa-check"></i> Dengan malakukan pendaftaran anda mengikuti syarat dan ketentuan yang berlaku</small>
								</label>
								<button type="submit" class="btn btn-success form-control"><i style="color: white" class="fas fa-sign-in-alt"></i> Daftar</button>
							</div>
						</div>
					</form>
					<footer class="w3-container" style="border-top: 1px solid #eee">
						<h6>Sudah memiliki akun? <a href="javascript:void(0)" data-toggle="modal" data-target="#modal_login">MASUK</a></h6>
					</footer>
				</div>
			</div>
		</div>
	</div>
	<div class="how slideanim">
		<div class="container w3-row">
			<div class="w3-col l12">
				<h1 class="w3-padding banner-from-title w3-align-center" style="font-weight: bolder;text-align: center;font-size: 30px!important">Menggunakan PLASTIKIND</h1>
			</div>
			<div class="w3-col l12">
				<img alt="how.png" src="<?=base_url('/assets/images/how.png')?>" style="width: 100%">
			</div>
		</div>
	</div>

	<div class="about w3-padding-64" style="padding: 100px 0px!important;background-color: #208C4C">
		<div class="container w3-row">
			<div class="w3-col l6 slideanim">
				<iframe style="width: 100%;height: 400px"src="https://www.youtube.com/embed/PtTTFXCW8oQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
			<div class="w3-col l6 w3-padding slideanim">
				<h1 class="banner-from-title w3-align-center" style="font-weight: bolder;color: white!important">Tentang PLASTIKIND</h1>
				<p style="color: white;font-size: 11px">
					Sumber sampah terbanyak adalah berasal dari pemukiman, komposisinya berupa 60-70% terdiri dari sampah organik dan hanya 30% sampah anorganik. 
					Tahukah anda?
					Hanya berkisar 15% saja sampah anonrganik yg dapat di daur ulang. Sampah anorganik yang paling banyak dijumpai di masyarakat adalah sampah plastik. Pada tahun 2019 produksi sampah plastik untuk kemasan mencapai 10 miliar lembar sampah produksi Kantong Belanja Plastik (KBP) dan sekitar 80%nya berpotensi menjadi sampah yang berbahaya bagi lingkungan. Karena potensinya yang cukup besar, alangkah lebih baik untuk memanfaatkan sampah plastik ini menjadi produk dan jasa kreatif dalam rangka mengelola sampah plastik dengan baik, sehingga plastik benar-benar mendukung kehidupan kita. Sebagai produk kreatif, karya kreasi sampah plastik memiliki nilai komersial yang menjanjikan. Produk ini memiliki daya jual yang dapat menghasilkan keuntungan.<br>
					Hal ini yang mendorong kami membuat <b style="color: white!important">plastikind</b> yaitu startup digital yang menawarkan solusi pengolahan limbah anorganik menjadi sebuah keuntungan bagi kita bersama dan terutama bagi lingkungan sehingga menciptakan masa depan yang lebih baik dengan lingkungan hidup yang semakin baik
				</p>
				<img alt="play-store.png" src="<?=base_url('/assets/images/ps.png')?>">
			</div>
		</div>
	</div>

	<div class="we  w3-padding-64">
		<div class="container w3-row">
			<div class="w3-col l12">
				<h1 class="w3-padding banner-from-title w3-align-center" style="font-weight: bolder;text-align: center;">OUR Best Team</h1>
			</div>
			<div class="w3-col l6 m6 w3-padding slideanim">
				<div class="shadow-sm overlay-container w3-padding-16">
					<div class="overlay w3-padding-16">Founder</div>
					<div class="w3-padding">
						<img alt="we.png" src="<?=base_url('assets/images/aep.jpeg')?>" style="width:100%;max-height: 200px;object-fit: contain;">
						<h4 style="width: 100%;text-align: center;text-transform: uppercase;font-weight: bold;color: white">Ahmad Saefudin</h4>
					</div>
				</div>
			</div>
			<div class="w3-col l6 m6 w3-padding slideanim">
				<div class="shadow-sm overlay-container w3-padding-16">
					<div class="overlay w3-padding-16">Co-Founder</div>
					<div class="w3-padding">
						<img alt="we.png" src="<?=base_url('assets/images/nando.jpeg')?>" style="width:100%;max-height: 200px;object-fit: contain;">
						<h4 style="width: 100%;text-align: center;text-transform: uppercase;font-weight: bold;color: white">Fernando Donica</h4>
					</div>
				</div>
			</div>
			<div class="w3-col l6 m6 w3-padding slideanim">
				<div class="shadow-sm overlay-container w3-padding-16">
					<div class="overlay w3-padding-16">Chief Marketing Officer</div>
					<div class="w3-padding">
						<img alt="we.png" src="<?=base_url('assets/images/bahri.jpeg')?>" style="width:100%;max-height: 200px;object-fit: contain;">
						<h4 style="width: 100%;text-align: center;text-transform: uppercase;font-weight: bold;color: white">Andika Bahri</h4>
					</div>
				</div>
			</div>
			<div class="w3-col l6 m6 w3-padding slideanim">
				<div class="shadow-sm overlay-container w3-padding-16">
					<div class="overlay w3-padding-16">Chief Operation Officer</div>
					<div class="w3-padding">
						<img alt="we.png" src="<?=base_url('assets/images/fergian.jpeg')?>" style="width:100%;max-height: 200px;object-fit: contain;">
						<h4 style="width: 100%;text-align: center;text-transform: uppercase;font-weight: bold;color: white">Fergian Ramdani</h4>
					</div>
				</div>
			</div>
		</div>
	</div>

	

	<div class="says slideanim">
		<div style="height: 150px; overflow: hidden;" class="w3-hide-small">
			<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
				<path d="M-3.67,28.13 C177.48,154.44 306.15,152.45 500.00,31.08 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #333;"></path>
			</svg>
		</div>
		<div style="height: 150px; overflow: hidden;" class="w3-hide-large w3-hide-medium" >
			<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
				<path d="M-3.10,90.28 C118.79,152.45 382.89,147.53 501.41,84.38 L500.00,150.00 L0.00,150.00 Z" style="stroke: none; fill: #333;"></path>
			</svg>
		</div>
		<div class="w3-padding-64" style="background-color: #333;min-height: 200px;">
			
			<div class="container w3-row">
				<div class="w3-col l12">
					<div id="carouselContent" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner" role="listbox">
							<div class="carousel-item active text-center p-4">
								<h3 style="color: white;font-weight: bold;">CUSTOMER</h3>
								<p style="color: white">Sangat visioner, pelayanannya pun sangat bagus dan memuaskan, Semoga Sukses</p>
							</div>
							<div class="carousel-item text-center p-4">
								<h3 style="color: white;font-weight: bold;">CUSTOMER</h3>
								<p style="color: white">Gak nyangka bisa dapat uang dari sampah yang kita kumpulkan, ide yang sangat cerdas sekali</p>
							</div>
						</div>
						<a class="carousel-control-prev" href="#carouselContent" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#carouselContent" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
			</div>

		</div>
		<div style="height: 150px; overflow: hidden;" class="w3-hide-small">
			<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
				<path d="M-0.27,105.09 C181.43,-1.47 332.67,-1.47 500.84,107.06 L500.00,0.00 L0.00,0.00 Z" style="stroke: none; fill: #333;"></path>
			</svg>
		</div>
		<div style="height: 150px; overflow: hidden;" class="w3-hide-medium w3-hide-large">
			<svg viewBox="0 0 500 150" preserveAspectRatio="none" style="height: 100%; width: 100%;">
				<path d="M0.00,49.98 C167.89,-2.45 347.35,-1.47 502.54,59.70 L500.00,0.00 L0.00,0.00 Z" style="stroke: none; fill: #333;"></path>
			</svg>
		</div>
	</div>

	<div class="contact slideanim container w3-row w3-padding-64 w3-container">
		<div class="w3-col l12">
			<h1 class="w3-padding banner-from-title w3-align-center" style="font-weight: bolder;text-align: center;"><i class="far fa-envelope"></i> Send Us Message</h1>
		</div>
		<div class="w3-card w3-col l12 w3-round w3-padding">
			<div class="form-group w3-col l6 w3-padding">
				<label>Nama Depan</label>
				<input type="text" name="first_name" class="form-control-lg form-control">
			</div>
			<div class="form-group w3-col l6 w3-padding">
				<label>Nama Belakang</label>
				<input type="text" name="first_name" class="form-control-lg form-control">
			</div>
			<div class="form-group w3-col l12 w3-padding">
				<label>Alamat Email</label>
				<input type="text" name="email" class="form-control-lg form-control">
			</div>
			<div class="form-group w3-col l12 w3-padding">
				<label>Your Message</label>
				<textarea rows="7" class="form-control"></textarea>
			</div>
			<div class="w3-padding">
				<button class="btn btn-primary w3-padding right"> <i class="far fa-paper-plane" style="color: white"></i> Kirim</button>
			</div>
		</div>
	</div>

	<div class="foot w3-padding-64" style="background-color: #333">
		<div class="container">
			<div class="w3-left" style="color: white">
				plastikind@2019&copy;
			</div>
			<div class="w3-right">
				<i class="fab fa-instagram fa-2x" style="color: white"></i>
				<i class="fab fa-facebook fa-2x" style="color: white"></i>
				<i class="fab fa-whatsapp fa-2x" style="color: white"></i>
			</div>
		</div>
	</div>

</section>

<?php 

$this->load->view('script/script_index');

 ?>