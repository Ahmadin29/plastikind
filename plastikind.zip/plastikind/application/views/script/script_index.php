<script type="text/javascript">
	
	$("#form-daftar").submit(function(e) {
		e.preventDefault();

		$('.fa-sign-in-alt').removeClass('fa-sign-in-alt').addClass('fa-spinner fa-spin');

		$.ajax({
			type:"post",
			url:"<?=base_url('/daftar')?>",
			data: $("#form-daftar").serialize(),
			success:function (res) {
				if (res === "") {
					location.href="<?=base_url('/verification')?>"
				}else{
					Swal.fire({
						type: 'error',
						title: 'Oops...',
						html: 'Something went wrong! '+res,
					});

					$('.fa-spinner').addClass('fa-sign-in-alt').removeClass('fa-spinner fa-spin');
				}
			},
			error:function(xhr,status,err) {
				Swal.fire({
					type: 'error',
					title: 'Oops...',
					html: 'Something went wrong! '+xhr.status+" "+xhr.statusText,
					footer: 'Please Tell Our Webmaster'
				})

			}
		})
	})

	$("#formLogin").submit(function(e) {
		e.preventDefault();

		$('.fa-sign-in-alt').removeClass('fa-sign-in-alt').addClass('fa-spinner fa-spin');

		$.ajax({
			type:"post",
			url:"<?=base_url('/login')?>",
			data:$(this).serialize(),
			success:function(res) {
				if (res === "") {
					location.href="<?=base_url('/')?>";
				}else{
					Swal.fire({
						type: 'error',
						title: 'Oops...',
						html: 'Something went wrong! '+res,
					})
					$('.fa-spinner').addClass('fa-sign-in-alt').removeClass('fa-spinner fa-spin');
				}
			},
			error:function(xhr,status,err){
				alert(xhr.status);
			}
		})
	})

</script>