<script type="text/javascript">
	
	$("#form-verification").submit(function(e) {
		e.preventDefault();

		$('.fa-sign-in-alt').removeClass('fa-sign-in-alt').addClass('fa-spinner fa-spin');

		$.ajax({
			type:"post",
			data:$(this).serialize(),
			url:"<?=base_url('/verification/user-verification')?>",
			success:function (res) {
				if (res === "") {
					location.href="<?=base_url('/')?>";
				}else{
					Swal.fire({
						type: 'error',
						title: 'Oops...',
						html: 'Something went wrong! '+res,
					});
					
					$('.fa-spinner').addClass('fa-sign-in-alt').removeClass('fa-spinner fa-spin');
				}
			},
			error:function (xhr) {
				Swal.fire({
					type: 'error',
					title: 'Oops...',
					html: 'Something went wrong! '+xhr.status+" "+xhr.statusText,
					footer: 'Please Tell Our Webmaster'
				})
			}
		})
	})

</script>