<html>
<head>
	<title>Halamand Depan | Plastikind</title>
	<!-- Latest compiled and minified CSS -->
	<meta charset="UTF-8">
	<meta name="description" content="Bank Sampah Online">
	<meta name="keywords" content="Bank Sampah, online, Bank sampah online jakarta, Bank Sampah online">
	<meta name="author" content="Ahmad Saefudin">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta property="og:url"                content="https://myplastikind.com" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="Plastikind | Bank sampah online" />
	<meta property="og:description"        content="Make better future with better life" />
	<meta property="og:image"              content="https://myplastikind.com/assets/images/icon.png" />

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="<?=base_url('assets/css/main.css')?>">
	<link rel="icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="shortcut icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/css/OverlayScrollbars.css">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/jquery.overlayScrollbars.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/OverlayScrollbars.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="https://kit.fontawesome.com/93a58dfd4a.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

	<script type="text/javascript">

		$("body").overlayScrollbars({

			className       : "os-theme-dark",
			resize          : "both",
			sizeAutoCapable : true,
			paddingAbsolute : true,
			scrollbars : {
				clickScrolling : true
			}

		})

		function showNav() {
			if ($(".navbar").css("right") != "0px" ) {
				$(".navbar").show();
				$(".navbar").animate({
					"right":"0px",
				});
			}else{
				$(".navbar").animate({
					"right":"-600px",
				},function() {
					$(".navbar").hide();
				});
			}
		}
		function showService() {
			$("#service").slideToggle();
		}
		$(window).on('load',function () {
			$(".loader").fadeOut();	
		})

		$(window).scroll(function() {
			$(".slideanim").each(function(){
				var pos = $(this).offset().top;

				var winTop = $(window).scrollTop();
				if (pos < winTop + 600) {
					$(this).addClass("slide");
				}
			});
		});
	</script>
	<style type="text/css">
		.slideanim {visibility:hidden;}
		.slide {
			animation-name: slide;
			animation-duration: 1s;
			visibility: visible;
		}
		@keyframes slide {
			0% {
				opacity: 0;
				transform: translateY(70%);
			} 
			100% {
				opacity: 1;
				transform: translateY(0%);
			}
		}
		.loader {
			position: fixed;
			left: 0px;
			top: 0px;
			width: 100%;
			height: 100%;
			z-index: 9999;
			background-color: white;
		}
		.load{
			border: 16px dotted #d3d3d3; /* Light grey */
			border-bottom-color: green;	
			border-top-color: green;	
			width: 50px;
			height: 50px;
			margin-right: 20px;
			float: left;
			animation: spin 1.5s linear infinite;
		}
		@keyframes spin {
			0% { transform: rotate(0deg); }
			100% { transform: rotate(360deg); }
		}
		h1{
			font-weight: bold;
			font-size: 50px;
			padding-bottom: 20px;
		}
		h1 .green{
			color: green;
		}
		h1 .black{
			color: #333;
		}
	</style>
</head>
<body>
	<div class="loader w3-display-container">
		<div class="w3-display-middle w3-center">
			<h1><div class="load"></div><span class="green">PLASTI</span><span class="black">KIND</span></h1>
		</div>
	</div>
	<div class="w3-card w3-white">
		<div class="container w3-padding-32">
			<img src="<?=base_url('/assets/images/icon.png')?>" class='icon-image'>
			<span class="icon-title">PLASTI<span>KIND</span></span>
			<span class="bar w3-right w3-hide-medium w3-hide-large" onclick="showNav()"><i class="fas fa-bars" style="width: 14px"></i></span>
		</div>
		<div class="w3-bar w3-light-grey sticky-top navbar w3-hide-medium w3-hide-large" style="display: none;right: -600px;top: 114px;position: absolute;">
			<div class="container">
				<a href="#" class="w3-bar-item w3-mobile">Halaman depan</a>
				<a href="#" class="w3-bar-item w3-mobile">Layanan</a>
				<a href="#" class="w3-bar-item w3-mobile">Tentang</a>
				<a href="#" class="w3-bar-item w3-mobile w3-right">Daftar</a>	
				<a href="javascript:void(0)" class="w3-bar-item w3-mobile w3-right" data-toggle="modal" data-target="#modal_login">MASUK</a>
			</div>
		</div>
	</div>
	<div class="w3-bar w3-padding-16 nav w3-card sticky-top bg-white w3-hide-small">
		<div class="container">
			<a href="#" class="w3-bar-item w3-mobile">Halaman depan</a>
			<a href="javascript:void(0)" class="w3-bar-item w3-mobile" onclick="showService()">Layanan</a>
			<a href="#" class="w3-bar-item w3-mobile">Tentang</a>
			<a href="javascript:void(0)" class="w3-bar-item w3-mobile w3-right" data-toggle="modal" data-target="#modal_login">MASUK</a>
		</div>

		<div class="subnav w3-bar w3-padding sticky-top w3-border-top" id="service" style="display: none;">
			<div class="container w3-row">
				<div class="w3-col l2 m4 s6 w3-margin-top submenu" style="text-align: center;">
					<i class="fas fa-box-open fa-4x mb-2"></i><br>
					Pengumpul Barang Bekas
				</div>
				<div class="w3-col l2 m4 s6 w3-margin-top submenu" style="text-align: center;">
					<i class="fas fa-money-bill-wave fa-4x mb-2"></i><br>
					Penjual Barang Bekas
				</div>
				<div class="w3-col l2 m4 s6 w3-margin-top submenu" style="text-align: center;">
					<i class="fas fa-tshirt fa-4x mb-2"></i><br>
					Merchendise
				</div>
			</div>
		</div>
	</div>

	<?php

	$this->load->view('modal/modal_login');

	?>
