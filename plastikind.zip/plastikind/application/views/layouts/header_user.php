<html>
<head>
	<title><?=$title?> | Plastikind</title>
	<!-- Latest compiled and minified CSS -->
	<meta charset="UTF-8">
	<meta name="description" content="Bank Sampah Online">
	<meta name="keywords" content="Bank Sampah, online, Bank sampah online jakarta, Bank Sampah online">
	<meta name="author" content="Ahmad Saefudin">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta property="og:url"                content="https://myplastikind.com" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="Plastikind | Bank sampah online" />
	<meta property="og:description"        content="Make better future with better life" />
	<meta property="og:image"              content="https://myplastikind.com/assets/images/icon.png" />

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="<?=base_url('assets/css/main_user.css')?>">
	<link rel="stylesheet" href="<?=base_url('assets/font-awesome/css/all.css')?>">
	<link rel="icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="shortcut icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/css/OverlayScrollbars.css">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/jquery.overlayScrollbars.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/OverlayScrollbars.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

	<script type="text/javascript">

		$("body").overlayScrollbars({

			className       : "os-theme-dark",
			resize          : "both",
			sizeAutoCapable : true,
			paddingAbsolute : true,
			scrollbars : {
				clickScrolling : true
			}

		})
		$(window).on('load',function () {
			$(".loader").fadeOut();	
		})
	</script>
	<style type="text/css">
		.loader {
			position: fixed;
			left: 0px;
			top: 0px;
			width: 100%;
			height: 100%;
			z-index: 9999;
			background-color: white;
		}
		.load{
			border: 16px dotted #d3d3d3; /* Light grey */
			border-bottom-color: green;	
			border-top-color: green;	
			width: 50px;
			height: 50px;
			margin-right: 20px;
			float: left;
			animation: spin 1.5s linear infinite;
		}
		@keyframes spin {
			0% { transform: rotate(0deg); }
			100% { transform: rotate(360deg); }
		}
		h1{
			font-weight: bold;
			font-size: 50px;
			padding-bottom: 20px;
		}
		h1 .green{
			color: green;
		}
		h1 .black{
			color: #333;
		}
	</style>
	<script type="text/javascript">
		function showside() {
			if ($(".active").css("right") != "0px") {

				$(".side-bar").css({"display":"block"});

				$(".side-bar").animate({
					"right":"0px",
				},500,function() {
					$(this).addClass("active");
				})
			}else{
				$(".side-bar").animate({
					"right":"-1000px",
				},500,function() {
					$(".side-bar").css({"display":"none"});
					$(this).addClass("active");
				})
			}
		}
	</script>
</head>
<body>
	<div class="loader w3-display-container">
		<div class="w3-display-middle w3-center">
			<h1><div class="load"></div><span class="green">PLASTI</span><span class="black">KIND</span></h1>
		</div>
	</div>
	<div class="w3-bar w3-padding-16 nav w3-card w3-green w3-hide-small">
		<div class="container" style="color: white">
			<a href="#" class="w3-bar-item w3-mobile"><i class="far fa-home" style="color: white"></i> Dashboard</a>
			<a href="javascript:void(0)" class="w3-bar-item w3-mobile" onclick="showService()"><i class="far fa-truck" style="color: white"></i> Permintaan</a>
			<a href="#" class="w3-bar-item w3-mobile"><i class="far fa-history" style="color: white"></i> Histori</a>
			<a href="<?=base_url('/logout')?>" class="w3-bar-item w3-mobile w3-right"><i class="far fa-sign-in-alt" style="color: white"></i> Keluar</a>
		</div>
	</div>
	<div class="w3-card w3-green w3-hide-large w3-hide-medium">
		<div class="w3-row" style="color: white">
			<div class="w3-padding-32 w3-col s1 w3-center w3-margin-left" onclick="showside()">
				<h3 style="font-weight: bold;text-transform: uppercase;"><span style="color: white">Plasti</span>kind</h3>
			</div>
			<div class="w3-padding-32 w3-col s1 w3-center w3-right w3-margin-right" onclick="showside()">
				<a href="#"><h3><i class="far fa-bars w3-text-white"></i></h3></a>
			</div>
		</div>
	</div>
	<div class="side-bar w3-row shadow-sm w3-display-container w3-hide-large w3-hide-medium" style="display: none;">
		<div class="w3-col l12">
			<div class="w3-col l12 w3-padding-32 w3-light-grey w3-center">
				<?php

				if ($user->photo =="") {
					?>

					<img src="<?=base_url('/assets/images/user-default.png')?>" class="user-profile">

					<?php
				}else{
					?>

					<img src="<?=base_url('/assets/images/')?><?=$user->photo?>" class="user-profile">

					<?php
				}

				?>

				<h4 style="font-weight: bold;"><?=$user->f_name." ".$user->l_name?></h4>
				<i class="far fa-coins"></i> 300 Points
			</div>
		</div>
		<div class="w3-padding w3-padding-16 w3-col l12">
			<a href="#"><i class="far fa-home"></i> Dashboard</a>
		</div>
		<div class="w3-padding w3-padding-16 w3-col l12">
			<a href="#"><i class="far fa-user-circle"></i> Edit Profile</a>
		</div>
		<div class="w3-padding w3-padding-16 w3-col l12">
			<a href="#"><i class="far fa-truck"></i> Permintaan</a>
		</div>
		<div class="w3-padding w3-col l9 w3-margin-left">
			<a href="#" class="profile-nav"><i class="far fa-clock"></i> Ditunda <span class="w3-text-green float-right w3-margin-right">90</span></a>
		</div>
		<div class="w3-padding w3-col l9 w3-margin-left">
			<a href="#" class="profile-nav"><i class="far fa-luggage-cart"></i> Diproses <span class="w3-text-green float-right w3-margin-right">90</span></a>
		</div>
		<div class="w3-padding w3-col l9 w3-margin-left">
			<a href="#" class="profile-nav"><i class="far fa-check-circle"></i> Selesai <span class="w3-text-green float-right w3-margin-right">90</span></a>
		</div>
		<div class="w3-padding w3-padding-16 w3-col l12">
			<a href="#"><i class="far fa-history"></i> History</a>
		</div>
		<div class="w3-padding w3-padding-16 w3-col l12 w3-display-bottommiddle w3-grey">
			<a href="<?=base_url('/logout')?>"><i class="far fa-sign-in-alt"></i> Keluar</a>
		</div>
	</div>