<div id="modal_login" class="modal fade " role="dialog">
	<div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header bg-blue">
				<h4 class="modal-title">Login Plastikind</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
			<form id="formLogin" method="post">				
				<div class="form-group">
					<label>E-mail</label>
					<input type="text" name="email" class="form-control">
				</div>

				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password" class="form-control">
				</div>

				<!-- <button class="btn btn-fb col-lg-12 w3-padding-16">
					<i class="fab fa-facebook-f" style="color: white"></i> Masuk Dengan Facebook
				</button>
				<button class="btn btn-g col-lg-12 w3-margin-top w3-padding-16">
					<i class="fab fa-google-plus-g" style="color: white"></i> Masuk Dengan Akun Google
				</button> -->

			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-success"><i style="color: white" class="fa fa-paper-plane"></i> Masuk</button>
			</div>
			</form>
		</div>

	</div>
</div>

<style type="text/css">
	.btn-fb{

		background-color: #3B5998;
		color: white;

	}

	.btn-g{
		background-color: #dd4b39;
		color: white;
	}
</style>