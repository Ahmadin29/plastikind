<!DOCTYPE html>
<html>
<head>
	<title>Verification Page</title>
	<!-- Latest compiled and minified CSS -->
	<meta charset="UTF-8">
	<meta name="description" content="Bank Sampah Online">
	<meta name="keywords" content="Bank Sampah, online, Bank sampah online jakarta, Bank Sampah online">
	<meta name="author" content="Ahmad Saefudin">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
	<meta property="og:url"                content="https://myplastikind.com" />
	<meta property="og:type"               content="article" />
	<meta property="og:title"              content="Plastikind | Bank sampah online" />
	<meta property="og:description"        content="Make better future with better life" />
	<meta property="og:image"              content="https://myplastikind.com/assets/images/icon.png" />

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="<?=base_url('assets/css/main.css')?>">
	<link rel="icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="shortcut icon" href="<?=base_url('/assets/images/favicon.ico')?>" type="image/x-icon"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/css/OverlayScrollbars.css">

	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/jquery.overlayScrollbars.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/overlayscrollbars/1.9.1/js/OverlayScrollbars.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="https://kit.fontawesome.com/93a58dfd4a.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>

</head>
<body>
	
	<section>
		<div class="w3-green">
			<div class="container w3-padding-32">
				<div class="title w3-container">
					<h1 class="w3-left" style="font-weight: bold;color: white">Verification Code</h1>
					<button class="btn btn-default w3-right" onclick="location.href='<?=base_url('/logout')?>'"><h4 style="color: white"><i class="fas fa-sign-in-alt" style="color: white"></i> Keluar</h4></button>
				</div>
			</div>
		</div>
		<div class="box container input-group-lg w3-padding-32">
			<p>Kami telah mengirimkan anda Kode Verfikasi melalui email yang anda daftarkan, silahkan cek Email anda untuk melihat kode verifikasi yang kami berikan untuk melanjutkan proses pendaftaran</p>
			<form id="form-verification">
				<input type="text" name="otp" class="form-control w3-light-grey" style="text-align: center;font-size: 50px;font-weight: bold;" maxlength="6">
				<button class="btn btn-success w3-margin-top float-right"><i style="color: white" class="far fa-paper-plane"></i> Kirim</button><br><br><p>tidak menerima email? kirim ulang dalam 00:00</p>
			</form>
		</div>
	</section>

	<?php
		$this->load->view('script/script_verification');
	?>
	
</body>
</html>