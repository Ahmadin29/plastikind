<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_controller extends CI_Controller {

	public function daftar()
	{
		$data['f_name'] 		= post('first_name');
		$data['l_name'] 		= post('last_name');
		$data['email'] 			= post('email');
		$data['phone'] 			= post('phone');
		$data['password'] 		= password_hash(post('password'), PASSWORD_DEFAULT);
		$data['otp']			= random(6);

		$check = database()->where('email',$data['email'])->get('users')->num_rows();

		if ($check > 0) {
			echo "E-mail sudah pernah didaftarkan, Silahkan login";die();
		}

		database()->insert('users',$data);

		$this->load->config('email');
		$this->load->library('email');

		$from = $this->config->item('smtp_user');
		$to = post('email');
		$subject = "Verification User Plastikind";
		$message = "Thanks to sign in our website \nPlease Insert <b>".$data['otp']."</b>To Verification Your Account At myplastikind.com";

		$this->email->set_newline("\r\n");
		$this->email->set_mailtype("html");
		$this->email->from($from);
		$this->email->to($to);
		$this->email->subject($subject);
		$this->email->message($message);

		if (!$this->email->send()) {
			show_error($this->email->print_debugger());
		}

		$user = database()->where('email',$data['email'])->get('users')->row();
		
		$this->session->set_userdata('id',$user->id);
		$this->session->set_userdata('email',$user->email);
		$this->session->set_userdata('name',$user->f_name." ".$user->l_name);
	}

	public function login()
	{
		$email = post('email');

		$user = database()->where('email',$email)->get('users');

		if ($user->num_rows() > 0) {

			$user = $user->row();

			if (password_verify(post('password'),$user->password)) {
				$this->session->set_userdata('id',$user->id);
				$this->session->set_userdata('email',$user->email);
				$this->session->set_userdata('name',$user->f_name." ".$user->l_name);
			}else{
				echo "Password Yang Anda Masukan Salah, Periksa Kembali Password Anda";
			}
		}else{
			echo "Email/username Tidak ditemukan! Silahkan mendaftar terlebih dahulu";
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('/');
	}

	public function verification()
	{
		$otp = post('otp');

		$where = array(

			'email'=>$this->session->email,
			'otp' => $otp

		);

		$data = database()->where($where)->get('users');

		$update = array(
			'status' => 'verified'
		);

		if ($data->num_rows() > 0) {
			database()->where('email',$where['email'])->update('users',$update);
		}else{
			echo "Kode Verifikasi yang anda masukan salah, coba cek kembali kode verfikasi yang anda masukan";
		}
	}
}
