<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$CI =& get_instance();

if ( ! function_exists('post'))
{
	function post($data)
	{
		global $CI;

		return $CI->input->post($data);
	}   
}

if ( ! function_exists('random'))
{
	function random($length) {
		$include_chars = "0123456789";
		/* Uncomment below to include symbols */
		/* $include_chars .= "[{(!@#$%^/&*_+;?\:)}]"; */
		$charLength = strlen($include_chars);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $include_chars [rand(0, $charLength - 1)];
		}
		return $randomString;
	}   
}

if ( ! function_exists('database'))
{
	function database()
	{
		global $CI;

		return $CI->db;
	}   
}

if ( ! function_exists('view'))
{
	function view($view,$data = null)
	{
		global $CI;

		return $CI->load->view($view,$data);
	}   
}